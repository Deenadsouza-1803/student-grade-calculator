# 🎓 Student Grade Calculator

A full-stack mini project that calculates a student's per-subject grades, overall
percentage, GPA, and pass/fail result — with a Node/Express backend, a vanilla
HTML/CSS/JS frontend, and a saved history of past calculations.

Built as a college mini-project reference implementation: simple enough to explain
in a viva, complete enough to actually run and demo.

---

## ✨ Features

- Add any number of subjects with marks and max marks
- Calculates, per subject: percentage, letter grade, pass/fail
- Calculates overall percentage, letter grade, GPA (10-point scale), and final result
- Saves every calculation to a history log (JSON file on the backend)
- View, and delete, past calculations from the UI
- Clean, responsive UI — works on mobile and desktop
- Zero external database required (JSON file storage) — runs anywhere Node runs

## 🏗️ Tech stack

| Layer     | Technology                          |
|-----------|--------------------------------------|
| Frontend  | HTML5, CSS3, vanilla JavaScript (fetch API) |
| Backend   | Node.js, Express.js                  |
| Storage   | JSON file (`backend/data/history.json`) |
| Testing   | Plain Node `assert` scripts          |

## 📁 Project structure

```
grade-calculator/
├── backend/
│   ├── server.js                 # Express app entry point
│   ├── routes/gradeRoutes.js      # API route definitions
│   ├── controllers/gradeController.js  # Request handlers
│   ├── utils/gradeLogic.js        # Pure grading logic (validation + calculation)
│   ├── tests/gradeLogic.test.js   # Unit tests for grading logic
│   ├── data/history.json          # Saved calculation history
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── presentation/
│   └── Student_Grade_Calculator.pptx   # Project presentation slides
└── README.md
```

## 🚀 Getting started

### Prerequisites
- [Node.js](https://nodejs.org/) v16 or newer

### 1. Clone and install
```bash
git clone https://github.com/<your-username>/grade-calculator.git
cd grade-calculator/backend
npm install
```

### 2. Run the server
```bash
npm start
# or, for auto-restart during development:
npm run dev
```

The server starts on **http://localhost:5000** and also serves the frontend
directly, so opening that URL in your browser gives you the full app —
no separate frontend server needed.

> Prefer to run the frontend on its own (e.g. VS Code Live Server)? Open
> `frontend/index.html` directly, and update `API_BASE` at the top of
> `frontend/script.js` to `http://localhost:5000/api`.

### 3. Run the tests (optional)
```bash
npm test
```

## 🔌 API reference

| Method | Endpoint            | Description                          |
|--------|----------------------|---------------------------------------|
| POST   | `/api/calculate`     | Calculate a result and save it to history |
| GET    | `/api/history`       | Get all saved calculations            |
| DELETE | `/api/history/:id`   | Delete one saved calculation          |
| DELETE | `/api/history`       | Clear all history                     |
| GET    | `/api/health`        | Health check                          |

**Example request body for `POST /api/calculate`:**
```json
{
  "studentName": "Asha Verma",
  "rollNumber": "21CS045",
  "subjects": [
    { "name": "Mathematics", "marks": 88, "maxMarks": 100 },
    { "name": "Science", "marks": 76, "maxMarks": 100 },
    { "name": "English", "marks": 91, "maxMarks": 100 }
  ]
}
```

**Example response:**
```json
{
  "id": "b3f1...",
  "studentName": "Asha Verma",
  "rollNumber": "21CS045",
  "subjects": [
    { "name": "Mathematics", "marks": 88, "maxMarks": 100, "percentage": 88, "grade": "A", "remark": "Excellent", "passed": true },
    { "name": "Science", "marks": 76, "maxMarks": 100, "percentage": 76, "grade": "B", "remark": "Very Good", "passed": true },
    { "name": "English", "marks": 91, "maxMarks": 100, "percentage": 91, "grade": "A+", "remark": "Outstanding", "passed": true }
  ],
  "totalMarks": 255,
  "totalMaxMarks": 300,
  "overallPercentage": 85,
  "overallGrade": "A",
  "overallRemark": "Excellent",
  "gpa": 9,
  "result": "PASS",
  "createdAt": "2026-01-01T10:00:00.000Z"
}
```

## 📊 Grading scale

| Percentage | Grade | Remark      |
|------------|-------|-------------|
| 90–100     | A+    | Outstanding |
| 80–89      | A     | Excellent   |
| 70–79      | B     | Very Good   |
| 60–69      | C     | Good        |
| 50–59      | D     | Average     |
| 40–49      | E     | Pass        |
| Below 40   | F     | Fail        |

A student's **overall result is PASS** only if every individual subject **and**
the overall percentage are 40% or above; otherwise the result is FAIL. This
threshold and the grade boundaries can be tuned in `backend/utils/gradeLogic.js`.

## 🔮 Possible extensions

- Swap the JSON file for a real database (MongoDB / PostgreSQL)
- Add user accounts and login (multiple students/teachers)
- Export a result as a PDF report card
- Add subject-wise weightage / credit-based GPA (as used in universities)
- Deploy: backend to Render/Railway, frontend to Vercel/Netlify (or serve both together, as configured here)

## 📄 License

MIT — free to use and adapt for coursework or personal projects.
