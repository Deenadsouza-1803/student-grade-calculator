const fs = require("fs");
const path = require("path");
const { randomUUID } = require("crypto");
const { calculateResult, validateSubjects } = require("../utils/gradeLogic");

const HISTORY_FILE = path.join(__dirname, "..", "data", "history.json");

function readHistory() {
  try {
    const raw = fs.readFileSync(HISTORY_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    return [];
  }
}

function writeHistory(history) {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
}

// POST /api/calculate
function calculate(req, res) {
  const { studentName, rollNumber, subjects } = req.body;

  const validation = validateSubjects(subjects);
  if (!validation.valid) {
    return res.status(400).json({ error: validation.error });
  }

  const resultData = calculateResult({ studentName, rollNumber, subjects });
  const record = {
    id: randomUUID(),
    ...resultData,
    createdAt: new Date().toISOString(),
  };

  const history = readHistory();
  history.unshift(record); // newest first
  writeHistory(history.slice(0, 200)); // cap history size

  return res.status(200).json(record);
}

// GET /api/history
function getHistory(req, res) {
  const history = readHistory();
  return res.status(200).json(history);
}

// DELETE /api/history/:id
function deleteHistoryItem(req, res) {
  const { id } = req.params;
  const history = readHistory();
  const filtered = history.filter((item) => item.id !== id);

  if (filtered.length === history.length) {
    return res.status(404).json({ error: "Record not found." });
  }

  writeHistory(filtered);
  return res.status(200).json({ message: "Record deleted." });
}

// DELETE /api/history  (clear all)
function clearHistory(req, res) {
  writeHistory([]);
  return res.status(200).json({ message: "History cleared." });
}

module.exports = { calculate, getHistory, deleteHistoryItem, clearHistory };
