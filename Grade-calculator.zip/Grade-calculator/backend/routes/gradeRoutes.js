const express = require("express");
const router = express.Router();
const {
  calculate,
  getHistory,
  deleteHistoryItem,
  clearHistory,
} = require("../controllers/gradeController");

router.post("/calculate", calculate);
router.get("/history", getHistory);
router.delete("/history/:id", deleteHistoryItem);
router.delete("/history", clearHistory);

module.exports = router;
