const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const gradeRoutes = require("./routes/gradeRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

// Ensure the data file exists so first run doesn't crash
const dataDir = path.join(__dirname, "data");
const historyFile = path.join(dataDir, "history.json");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
if (!fs.existsSync(historyFile)) fs.writeFileSync(historyFile, "[]");

app.use(cors());
app.use(express.json());

// Serve the frontend as static files too, so `npm start` alone is enough
// to run the whole project (frontend calls /api/* on the same origin).
app.use(express.static(path.join(__dirname, "..", "frontend")));

app.use("/api", gradeRoutes);

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Grade Calculator API is running." });
});

app.listen(PORT, () => {
  console.log(`✅ Student Grade Calculator server running on http://localhost:${PORT}`);
});
