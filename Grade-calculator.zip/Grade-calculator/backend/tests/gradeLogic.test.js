/**
 * Minimal assertion-based tests — no test framework dependency needed
 * for a mini project. Run with: npm test
 */
const assert = require("assert");
const { calculateResult, validateSubjects } = require("../utils/gradeLogic");

function test(description, fn) {
  try {
    fn();
    console.log(`✅ PASS: ${description}`);
  } catch (err) {
    console.error(`❌ FAIL: ${description}`);
    console.error(err.message);
    process.exitCode = 1;
  }
}

test("rejects empty subjects array", () => {
  const { valid, error } = validateSubjects([]);
  assert.strictEqual(valid, false);
  assert.ok(error);
});

test("rejects marks greater than max marks", () => {
  const { valid } = validateSubjects([{ name: "Math", marks: 120, maxMarks: 100 }]);
  assert.strictEqual(valid, false);
});

test("calculates overall PASS correctly", () => {
  const result = calculateResult({
    studentName: "Test Student",
    rollNumber: "R001",
    subjects: [
      { name: "Math", marks: 90, maxMarks: 100 },
      { name: "Science", marks: 85, maxMarks: 100 },
      { name: "English", marks: 78, maxMarks: 100 },
    ],
  });
  assert.strictEqual(result.result, "PASS");
  assert.strictEqual(result.overallPercentage, 84.33);
  assert.strictEqual(result.overallGrade, "A");
});

test("fails overall result if any subject is below pass threshold", () => {
  const result = calculateResult({
    studentName: "Test Student 2",
    subjects: [
      { name: "Math", marks: 90, maxMarks: 100 },
      { name: "Science", marks: 30, maxMarks: 100 }, // below 40%
    ],
  });
  assert.strictEqual(result.result, "FAIL");
});

test("handles subjects with custom max marks", () => {
  const result = calculateResult({
    studentName: "Test Student 3",
    subjects: [{ name: "Lab", marks: 45, maxMarks: 50 }],
  });
  assert.strictEqual(result.subjects[0].percentage, 90);
  assert.strictEqual(result.subjects[0].grade, "A+");
});

console.log("\nAll tests executed.");
