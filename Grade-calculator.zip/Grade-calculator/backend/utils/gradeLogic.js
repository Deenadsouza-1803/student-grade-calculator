/**
 * Core grading logic for the Student Grade Calculator.
 * Kept separate from routes/controllers so it can be unit-tested in isolation.
 */

// Grade boundaries (percentage -> grade). Order matters: highest first.
const GRADE_SCALE = [
  { min: 90, grade: "A+", remark: "Outstanding" },
  { min: 80, grade: "A", remark: "Excellent" },
  { min: 70, grade: "B", remark: "Very Good" },
  { min: 60, grade: "C", remark: "Good" },
  { min: 50, grade: "D", remark: "Average" },
  { min: 40, grade: "E", remark: "Pass" },
  { min: 0, grade: "F", remark: "Fail" },
];

const PASS_THRESHOLD = 40; // percentage required, per subject and overall

function getGradeForPercentage(percentage) {
  const band = GRADE_SCALE.find((g) => percentage >= g.min);
  return band || GRADE_SCALE[GRADE_SCALE.length - 1];
}

/**
 * Validate the raw subjects array coming from the client.
 * Returns { valid: boolean, error?: string }
 */
function validateSubjects(subjects) {
  if (!Array.isArray(subjects) || subjects.length === 0) {
    return { valid: false, error: "At least one subject is required." };
  }
  for (const s of subjects) {
    if (!s || typeof s.name !== "string" || !s.name.trim()) {
      return { valid: false, error: "Every subject needs a name." };
    }
    const marks = Number(s.marks);
    const maxMarks = Number(s.maxMarks) || 100;
    if (Number.isNaN(marks) || marks < 0) {
      return { valid: false, error: `Invalid marks for "${s.name}".` };
    }
    if (marks > maxMarks) {
      return {
        valid: false,
        error: `Marks for "${s.name}" (${marks}) exceed max marks (${maxMarks}).`,
      };
    }
  }
  return { valid: true };
}

/**
 * Compute per-subject grades plus the overall result for a student.
 * @param {{name: string, rollNumber?: string, subjects: {name:string, marks:number, maxMarks?:number}[]}} payload
 */
function calculateResult(payload) {
  const { studentName, rollNumber, subjects } = payload;

  const gradedSubjects = subjects.map((s) => {
    const marks = Number(s.marks);
    const maxMarks = Number(s.maxMarks) || 100;
    const percentage = (marks / maxMarks) * 100;
    const { grade, remark } = getGradeForPercentage(percentage);
    return {
      name: s.name.trim(),
      marks,
      maxMarks,
      percentage: Number(percentage.toFixed(2)),
      grade,
      remark,
      passed: percentage >= PASS_THRESHOLD,
    };
  });

  const totalMarks = gradedSubjects.reduce((sum, s) => sum + s.marks, 0);
  const totalMaxMarks = gradedSubjects.reduce((sum, s) => sum + s.maxMarks, 0);
  const overallPercentage = totalMaxMarks
    ? Number(((totalMarks / totalMaxMarks) * 100).toFixed(2))
    : 0;

  const { grade: overallGrade, remark: overallRemark } =
    getGradeForPercentage(overallPercentage);

  const allSubjectsPassed = gradedSubjects.every((s) => s.passed);
  const result =
    allSubjectsPassed && overallPercentage >= PASS_THRESHOLD ? "PASS" : "FAIL";

  // Simple 4-point GPA mapped from grade letters, average across subjects.
  const GPA_MAP = { "A+": 10, A: 9, B: 8, C: 7, D: 6, E: 5, F: 0 };
  const gpa = Number(
    (
      gradedSubjects.reduce((sum, s) => sum + GPA_MAP[s.grade], 0) /
      gradedSubjects.length
    ).toFixed(2)
  );

  return {
    studentName: studentName?.trim() || "Unnamed Student",
    rollNumber: rollNumber?.trim() || "N/A",
    subjects: gradedSubjects,
    totalMarks,
    totalMaxMarks,
    overallPercentage,
    overallGrade,
    overallRemark,
    gpa,
    result,
  };
}

module.exports = { calculateResult, validateSubjects, PASS_THRESHOLD, GRADE_SCALE };
