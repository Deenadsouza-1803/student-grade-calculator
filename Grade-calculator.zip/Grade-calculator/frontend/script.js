// Same-origin by default (backend serves this frontend too).
// If you run the frontend separately (e.g. Live Server), change this
// to "http://localhost:5000/api".
const API_BASE = "/api";

const els = {
  apiStatus: document.getElementById("api-status"),
  form: document.getElementById("grade-form"),
  studentName: document.getElementById("studentName"),
  rollNumber: document.getElementById("rollNumber"),
  subjectsList: document.getElementById("subjects-list"),
  addSubjectBtn: document.getElementById("add-subject"),
  resetBtn: document.getElementById("reset-form"),
  formError: document.getElementById("form-error"),
  rowTemplate: document.getElementById("subject-row-template"),

  resultEmpty: document.getElementById("result-empty"),
  resultContent: document.getElementById("result-content"),
  resultName: document.getElementById("result-name"),
  resultRoll: document.getElementById("result-roll"),
  resultBadge: document.getElementById("result-badge"),
  statPercentage: document.getElementById("stat-percentage"),
  statGrade: document.getElementById("stat-grade"),
  statGpa: document.getElementById("stat-gpa"),
  subjectTableBody: document.getElementById("subject-table-body"),

  historyEmpty: document.getElementById("history-empty"),
  historyList: document.getElementById("history-list"),
  clearHistoryBtn: document.getElementById("clear-history"),
};

function addSubjectRow(prefill) {
  const fragment = els.rowTemplate.content.cloneNode(true);
  const row = fragment.querySelector("[data-row]");
  if (prefill) {
    row.querySelector(".subject-name").value = prefill.name || "";
    row.querySelector(".subject-marks").value = prefill.marks ?? "";
    row.querySelector(".subject-max").value = prefill.maxMarks ?? 100;
  }
  row.querySelector(".remove-subject").addEventListener("click", () => {
    // Always keep at least one row.
    if (els.subjectsList.children.length > 1) row.remove();
  });
  els.subjectsList.appendChild(row);
}

function resetForm() {
  els.form.reset();
  els.subjectsList.innerHTML = "";
  addSubjectRow({ name: "Mathematics", marks: "", maxMarks: 100 });
  addSubjectRow({ name: "Science", marks: "", maxMarks: 100 });
  addSubjectRow({ name: "English", marks: "", maxMarks: 100 });
  hideError();
}

function showError(message) {
  els.formError.textContent = message;
  els.formError.hidden = false;
}
function hideError() {
  els.formError.hidden = true;
}

function collectSubjects() {
  return [...els.subjectsList.querySelectorAll("[data-row]")].map((row) => ({
    name: row.querySelector(".subject-name").value,
    marks: Number(row.querySelector(".subject-marks").value),
    maxMarks: Number(row.querySelector(".subject-max").value) || 100,
  }));
}

function gradeClass(grade) {
  return grade === "F" ? "fail-pill" : "";
}

function renderResult(record) {
  els.resultEmpty.hidden = true;
  els.resultContent.hidden = false;

  els.resultName.textContent = record.studentName;
  els.resultRoll.textContent =
    record.rollNumber && record.rollNumber !== "N/A" ? `Roll no. ${record.rollNumber}` : "";

  els.resultBadge.textContent = record.result;
  els.resultBadge.className = `badge ${record.result === "PASS" ? "pass" : "fail"}`;

  els.statPercentage.textContent = `${record.overallPercentage}%`;
  els.statGrade.textContent = record.overallGrade;
  els.statGpa.textContent = record.gpa;

  els.subjectTableBody.innerHTML = record.subjects
    .map(
      (s) => `
      <tr>
        <td>${escapeHtml(s.name)}</td>
        <td>${s.marks}/${s.maxMarks}</td>
        <td>${s.percentage}%</td>
        <td><span class="grade-pill ${gradeClass(s.grade)}">${s.grade}</span></td>
      </tr>`
    )
    .join("");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function timeAgo(isoString) {
  const diffMs = Date.now() - new Date(isoString).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  return new Date(isoString).toLocaleDateString();
}

function renderHistory(items) {
  if (!items.length) {
    els.historyEmpty.hidden = false;
    els.historyList.innerHTML = "";
    return;
  }
  els.historyEmpty.hidden = true;
  els.historyList.innerHTML = items
    .map(
      (item) => `
      <div class="history-item" data-id="${item.id}">
        <div class="history-main">
          <span class="history-name">${escapeHtml(item.studentName)}</span>
          <span class="history-meta">${item.overallPercentage}% · Grade ${item.overallGrade} · ${timeAgo(item.createdAt)}</span>
        </div>
        <div class="history-right">
          <span class="badge ${item.result === "PASS" ? "pass" : "fail"}">${item.result}</span>
          <button class="delete-history" data-delete="${item.id}" title="Delete">Delete</button>
        </div>
      </div>`
    )
    .join("");

  els.historyList.querySelectorAll("[data-delete]").forEach((btn) => {
    btn.addEventListener("click", () => deleteHistoryItem(btn.dataset.delete));
  });
}

async function checkApiHealth() {
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw new Error();
    els.apiStatus.textContent = "backend connected";
    els.apiStatus.className = "api-status online";
  } catch {
    els.apiStatus.textContent = "backend offline";
    els.apiStatus.className = "api-status offline";
  }
}

async function loadHistory() {
  try {
    const res = await fetch(`${API_BASE}/history`);
    const data = await res.json();
    renderHistory(data);
  } catch {
    renderHistory([]);
  }
}

async function deleteHistoryItem(id) {
  try {
    await fetch(`${API_BASE}/history/${id}`, { method: "DELETE" });
    loadHistory();
  } catch {
    // Silently ignore — history is a convenience feature, not core to the tool.
  }
}

els.clearHistoryBtn.addEventListener("click", async () => {
  if (!confirm("Clear all saved calculations?")) return;
  try {
    await fetch(`${API_BASE}/history`, { method: "DELETE" });
    loadHistory();
  } catch {
    /* noop */
  }
});

els.addSubjectBtn.addEventListener("click", () => addSubjectRow());
els.resetBtn.addEventListener("click", resetForm);

els.form.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideError();

  const subjects = collectSubjects();
  if (subjects.some((s) => !s.name.trim())) {
    showError("Please name every subject.");
    return;
  }
  if (subjects.some((s) => Number.isNaN(s.marks))) {
    showError("Please enter marks for every subject.");
    return;
  }

  const payload = {
    studentName: els.studentName.value,
    rollNumber: els.rollNumber.value,
    subjects,
  };

  try {
    const res = await fetch(`${API_BASE}/calculate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showError(data.error || "Something went wrong. Please check your inputs.");
      return;
    }

    renderResult(data);
    loadHistory();
  } catch (err) {
    showError("Could not reach the backend. Is the server running?");
  }
});

// Init
resetForm();
checkApiHealth();
loadHistory();
