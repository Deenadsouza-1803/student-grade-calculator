const pptxgen = require("pptxgenjs");

// ---------- Palette ("Midnight Executive" + gold accent, matches frontend UI) ----------
const NAVY = "1E2761";
const NAVY_DARK = "141A44";
const ICE = "CADCFC";
const GOLD = "C99A3D";
const WHITE = "FFFFFF";
const INK = "1B1F2A";
const INK_SOFT = "5B6072";
const PAPER = "F6F7FB";
const PASS_GREEN = "206B3A";
const PASS_BG = "E4F3E9";
const FAIL_RED = "A02A2A";
const FAIL_BG = "FBE9E9";
const LINE = "E3E5EE";

const FONT_HEAD = "Cambria";   // safe serif, ships with Office, renders true-width in QA
const FONT_BODY = "Calibri";   // safe sans

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.3" x 7.5"
const PAGE_W = 13.33;
const PAGE_H = 7.5;

// ---------- Helpers ----------
function darkSlide() {
  const s = pres.addSlide();
  s.background = { color: NAVY_DARK };
  return s;
}
function lightSlide() {
  const s = pres.addSlide();
  s.background = { color: PAPER };
  return s;
}

function kicker(slide, text, opts = {}) {
  slide.addText(text.toUpperCase(), {
    x: opts.x ?? 0.6,
    y: opts.y ?? 0.45,
    w: opts.w ?? 8,
    h: 0.35,
    fontFace: FONT_BODY,
    fontSize: 12,
    color: opts.color ?? GOLD,
    charSpacing: 2,
    bold: true,
    isTextBox: true,
    margin: 0,
  });
}

function title(slide, text, opts = {}) {
  slide.addText(text, {
    x: opts.x ?? 0.6,
    y: opts.y ?? 0.78,
    w: opts.w ?? 11.5,
    h: opts.h ?? 0.8,
    fontFace: FONT_HEAD,
    fontSize: opts.size ?? 32,
    bold: true,
    color: opts.color ?? NAVY_DARK,
    isTextBox: true,
    margin: 0,
  });
}

function pageNumber(slide, n) {
  slide.addText(String(n).padStart(2, "0"), {
    x: PAGE_W - 0.9,
    y: PAGE_H - 0.5,
    w: 0.6,
    h: 0.3,
    fontFace: FONT_BODY,
    fontSize: 10,
    color: INK_SOFT,
    align: "right",
    isTextBox: true,
    margin: 0,
  });
}

function iconCircle(slide, x, y, diameter, glyph, opts = {}) {
  slide.addShape(pres.ShapeType.ellipse, {
    x, y, w: diameter, h: diameter,
    fill: { color: opts.fill ?? NAVY },
    line: { type: "none" },
  });
  slide.addText(glyph, {
    x, y, w: diameter, h: diameter,
    align: "center",
    valign: "middle",
    fontSize: opts.fontSize ?? diameter * 22,
    color: opts.color ?? WHITE,
    fontFace: FONT_BODY,
    isTextBox: true,
    margin: 0,
  });
}

// =====================================================================
// SLIDE 1 — TITLE
// =====================================================================
{
  const s = darkSlide();
  // subtle decorative circle motif (no accent stripes)
  s.addShape(pres.ShapeType.ellipse, {
    x: 9.6, y: -2.2, w: 7, h: 7, fill: { color: NAVY, transparency: 40 }, line: { type: "none" },
  });
  s.addShape(pres.ShapeType.ellipse, {
    x: 10.6, y: -1.2, w: 4.2, h: 4.2, fill: { color: GOLD, transparency: 78 }, line: { type: "none" },
  });

  s.addText("MINI PROJECT  ·  FULL-STACK WEB APPLICATION", {
    x: 0.8, y: 2.35, w: 9, h: 0.4,
    fontFace: FONT_BODY, fontSize: 13, color: GOLD, bold: true, charSpacing: 2,
    isTextBox: true, margin: 0,
  });
  s.addText("Student Grade\nCalculator", {
    x: 0.75, y: 2.75, w: 9.5, h: 2.1,
    fontFace: FONT_HEAD, fontSize: 52, bold: true, color: WHITE,
    isTextBox: true, margin: 0, lineSpacingMultiple: 1.02,
  });
  s.addText("Automated grade, percentage and result calculation — built with a Node.js/Express backend and a lightweight JavaScript frontend.", {
    x: 0.8, y: 4.95, w: 8.4, h: 0.7,
    fontFace: FONT_BODY, fontSize: 14.5, color: ICE, isTextBox: true, margin: 0,
  });

  s.addShape(pres.ShapeType.line, {
    x: 0.8, y: 6.15, w: 3.2, h: 0, line: { color: GOLD, width: 1.5 },
  });
  s.addText("Presented by:  [Your Name]", {
    x: 0.8, y: 6.3, w: 5, h: 0.35,
    fontFace: FONT_BODY, fontSize: 12.5, color: WHITE, isTextBox: true, margin: 0,
  });
  s.addText("Department of Computer Science  ·  [Institution Name]  ·  [Date]", {
    x: 0.8, y: 6.65, w: 8, h: 0.35,
    fontFace: FONT_BODY, fontSize: 11.5, color: ICE, isTextBox: true, margin: 0,
  });
}

// =====================================================================
// SLIDE 2 — INTRODUCTION
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "Introduction");
  title(s, "What the project does");

  const introPoints = [
    { icon: "✎", head: "Enter marks", body: "A student or teacher enters marks for any number of subjects, along with the maximum marks for each." },
    { icon: "∑", head: "Auto-calculate", body: "The backend computes per-subject percentage and grade, plus the overall percentage, GPA and result." },
    { icon: "▤", head: "Track history", body: "Every calculation is saved automatically, so past results can be reviewed or removed later." },
  ];

  introPoints.forEach((p, i) => {
    const x = 0.6 + i * 4.1;
    iconCircle(s, x, 2.0, 0.75, p.icon, { fill: NAVY });
    s.addText(p.head, {
      x, y: 2.95, w: 3.7, h: 0.4, fontFace: FONT_HEAD, fontSize: 17, bold: true, color: NAVY_DARK,
      isTextBox: true, margin: 0,
    });
    s.addText(p.body, {
      x, y: 3.4, w: 3.7, h: 1.5, fontFace: FONT_BODY, fontSize: 12.5, color: INK_SOFT,
      isTextBox: true, margin: 0, lineSpacingMultiple: 1.15,
    });
  });

  s.addShape(pres.ShapeType.roundRect, {
    x: 0.6, y: 5.35, w: 12.1, h: 1.35, rectRadius: 0.1,
    fill: { color: WHITE }, line: { color: LINE, width: 1 },
    shadow: { type: "outer", color: "9AA1B5", opacity: 0.25, blur: 8, offset: 2, angle: 90 },
  });
  s.addText("Manual grading is slow and error-prone when a class has many students and subjects. This project automates the arithmetic and standardises the grading scale, while keeping a simple, explainable rule set that's easy to defend in a viva.", {
    x: 0.9, y: 5.5, w: 11.5, h: 1.05, fontFace: FONT_BODY, fontSize: 13, italic: true, color: INK,
    isTextBox: true, margin: 0, valign: "middle",
  });
  pageNumber(s, 2);
}

// =====================================================================
// SLIDE 3 — OBJECTIVES
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "Objectives");
  title(s, "Project objectives");

  const objectives = [
    "Build a working full-stack app: frontend UI, backend API, and persistent storage.",
    "Automate percentage, grade and GPA calculation for any number of subjects.",
    "Apply a consistent, rule-based grading scale (per subject and overall).",
    "Persist calculation history so results can be reviewed without recalculating.",
    "Expose a clean REST API that could be reused by a mobile app or LMS later.",
    "Keep the codebase small enough to read end-to-end and explain in a viva.",
  ];

  const colW = 5.85;
  objectives.forEach((obj, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.6 + col * (colW + 0.4);
    const y = 2.05 + row * 1.55;

    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: colW, h: 1.3, rectRadius: 0.08,
      fill: { color: WHITE }, line: { color: LINE, width: 1 },
    });
    s.addShape(pres.ShapeType.ellipse, {
      x: x + 0.25, y: y + 0.25, w: 0.5, h: 0.5, fill: { color: GOLD }, line: { type: "none" },
    });
    s.addText(String(i + 1), {
      x: x + 0.25, y: y + 0.25, w: 0.5, h: 0.5, align: "center", valign: "middle",
      fontFace: FONT_HEAD, fontSize: 16, bold: true, color: NAVY_DARK, isTextBox: true, margin: 0,
    });
    s.addText(obj, {
      x: x + 0.95, y: y + 0.15, w: colW - 1.2, h: 1.0, valign: "middle",
      fontFace: FONT_BODY, fontSize: 12.5, color: INK, isTextBox: true, margin: 0, lineSpacingMultiple: 1.1,
    });
  });
  pageNumber(s, 3);
}

// =====================================================================
// SLIDE 4 — SYSTEM ARCHITECTURE
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "System design");
  title(s, "System architecture");

  const boxY = 3.0, boxH = 1.5, boxW = 2.55, gap = 0.55;
  const boxes = [
    { label: "Frontend", sub: "HTML · CSS · JS\n(fetch API)", fill: NAVY },
    { label: "Express API", sub: "Routes &\nControllers", fill: NAVY },
    { label: "Grade Logic", sub: "Validation &\nCalculation", fill: NAVY },
    { label: "JSON Storage", sub: "history.json\n(file-based)", fill: NAVY },
  ];
  const totalW = boxes.length * boxW + (boxes.length - 1) * gap;
  let startX = (PAGE_W - totalW) / 2;

  boxes.forEach((b, i) => {
    const x = startX + i * (boxW + gap);
    s.addShape(pres.ShapeType.roundRect, {
      x, y: boxY, w: boxW, h: boxH, rectRadius: 0.09,
      fill: { color: b.fill }, line: { type: "none" },
      shadow: { type: "outer", color: "9AA1B5", opacity: 0.3, blur: 10, offset: 3, angle: 90 },
    });
    s.addText(b.label, {
      x, y: boxY + 0.25, w: boxW, h: 0.4, align: "center",
      fontFace: FONT_HEAD, fontSize: 15, bold: true, color: WHITE, isTextBox: true, margin: 0,
    });
    s.addText(b.sub, {
      x, y: boxY + 0.68, w: boxW, h: 0.7, align: "center",
      fontFace: FONT_BODY, fontSize: 11, color: ICE, isTextBox: true, margin: 0, lineSpacingMultiple: 1.15,
    });
    if (i < boxes.length - 1) {
      s.addText("→", {
        x: x + boxW, y: boxY + 0.45, w: gap, h: 0.6, align: "center", valign: "middle",
        fontFace: FONT_BODY, fontSize: 22, bold: true, color: GOLD, isTextBox: true, margin: 0,
      });
    }
  });

  s.addText("Request flow", {
    x: startX, y: boxY + boxH + 0.35, w: 4, h: 0.35,
    fontFace: FONT_BODY, fontSize: 12, bold: true, color: INK_SOFT, isTextBox: true, margin: 0,
  });
  s.addText("The browser submits marks to POST /api/calculate → Express routes the request to the grade controller → gradeLogic.js validates input and computes results → the record is saved to history.json and returned as JSON → the frontend renders the grade card.", {
    x: startX, y: boxY + boxH + 0.7, w: totalW, h: 1.0,
    fontFace: FONT_BODY, fontSize: 12.5, color: INK, isTextBox: true, margin: 0, lineSpacingMultiple: 1.2,
  });
  pageNumber(s, 4);
}

// =====================================================================
// SLIDE 5 — TECHNOLOGY STACK
// =====================================================================
{
  const s = darkSlide();
  kicker(s, "Technology stack", { color: GOLD });
  title(s, "Built with", { color: WHITE });

  const stack = [
    { icon: "◉", name: "HTML5 & CSS3", role: "Structure & styling" },
    { icon: "◈", name: "JavaScript", role: "Frontend interactivity" },
    { icon: "▣", name: "Node.js", role: "Runtime environment" },
    { icon: "▦", name: "Express.js", role: "REST API framework" },
    { icon: "▤", name: "JSON file store", role: "Persisting history" },
    { icon: "✓", name: "Node assert", role: "Unit testing" },
  ];

  stack.forEach((t, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = 0.9 + col * 4.0;
    const y = 2.3 + row * 2.15;

    iconCircle(s, x, y, 0.85, t.icon, { fill: GOLD, color: NAVY_DARK, fontSize: 24 });
    s.addText(t.name, {
      x: x - 0.3, y: y + 1.0, w: 3.4, h: 0.4, align: "center",
      fontFace: FONT_HEAD, fontSize: 15, bold: true, color: WHITE, isTextBox: true, margin: 0,
    });
    s.addText(t.role, {
      x: x - 0.3, y: y + 1.4, w: 3.4, h: 0.4, align: "center",
      fontFace: FONT_BODY, fontSize: 11.5, color: ICE, isTextBox: true, margin: 0,
    });
  });
  pageNumber(s, 5);
}

// =====================================================================
// SLIDE 6 — GRADING SCALE (TABLE)
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "Core logic");
  title(s, "Grading scale");

  const rows = [
    [
      { text: "Percentage", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      { text: "Grade", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      { text: "Remark", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
    ],
    ["90 – 100", "A+", "Outstanding"],
    ["80 – 89", "A", "Excellent"],
    ["70 – 79", "B", "Very Good"],
    ["60 – 69", "C", "Good"],
    ["50 – 59", "D", "Average"],
    ["40 – 49", "E", "Pass"],
    ["Below 40", "F", "Fail"],
  ].map((row, ri) =>
    Array.isArray(row) && ri > 0
      ? row.map((cell) => ({
          text: cell,
          options: {
            color: INK,
            fill: { color: ri % 2 === 0 ? WHITE : PAPER },
            fontFace: FONT_BODY,
          },
        }))
      : row
  );

  s.addTable(rows, {
    x: 0.6, y: 2.0, w: 7.4, h: 4.6,
    fontFace: FONT_BODY, fontSize: 14,
    border: { type: "solid", color: LINE, pt: 1 },
    autoPage: false,
    valign: "middle",
    rowH: 0.58,
  });

  s.addShape(pres.ShapeType.roundRect, {
    x: 8.35, y: 2.0, w: 4.35, h: 4.6, rectRadius: 0.1,
    fill: { color: NAVY }, line: { type: "none" },
  });
  s.addText("Pass rule", {
    x: 8.65, y: 2.3, w: 3.8, h: 0.4, fontFace: FONT_HEAD, fontSize: 17, bold: true, color: GOLD,
    isTextBox: true, margin: 0,
  });
  s.addText("A result is marked PASS only when:", {
    x: 8.65, y: 2.85, w: 3.8, h: 0.4, fontFace: FONT_BODY, fontSize: 12.5, color: ICE,
    isTextBox: true, margin: 0,
  });
  [
    "Every individual subject scores 40% or above",
    "The overall percentage is 40% or above",
  ].forEach((t, i) => {
    s.addText(t, {
      x: 8.65, y: 3.35 + i * 0.85, w: 3.8, h: 0.75,
      fontFace: FONT_BODY, fontSize: 12.5, color: WHITE, bullet: { code: "2022" },
      isTextBox: true, margin: 0, lineSpacingMultiple: 1.15,
    });
  });
  s.addText("Otherwise the result is FAIL — even if the overall average alone looks fine. Thresholds live in gradeLogic.js and are easy to retune.", {
    x: 8.65, y: 5.15, w: 3.8, h: 1.3, fontFace: FONT_BODY, fontSize: 11.5, italic: true, color: ICE,
    isTextBox: true, margin: 0, lineSpacingMultiple: 1.2,
  });
  pageNumber(s, 6);
}

// =====================================================================
// SLIDE 7 — MODULES / FEATURES
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "Features");
  title(s, "Modules at a glance");

  const modules = [
    { icon: "①", head: "Marks entry form", body: "Dynamic subject rows — add or remove subjects on the fly, with per-subject max marks." },
    { icon: "②", head: "Calculation engine", body: "Pure, testable functions compute percentage, grade, GPA and pass/fail per subject and overall." },
    { icon: "③", head: "Result dashboard", body: "A grade card shows the overall percentage, grade, GPA and a PASS/FAIL badge at a glance." },
    { icon: "④", head: "History log", body: "Past calculations persist in history.json and can be reviewed or deleted from the UI." },
    { icon: "⑤", head: "REST API", body: "Clean /api endpoints (calculate, history, health) that any client could reuse." },
    { icon: "⑥", head: "Input validation", body: "Rejects missing names, negative marks, or marks exceeding the maximum, with clear errors." },
  ];

  modules.forEach((m, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = 0.6 + col * 4.15;
    const y = 2.0 + row * 2.55;

    s.addShape(pres.ShapeType.roundRect, {
      x, y, w: 3.9, h: 2.3, rectRadius: 0.09,
      fill: { color: WHITE }, line: { color: LINE, width: 1 },
    });
    s.addText(m.icon, {
      x: x + 0.25, y: y + 0.2, w: 0.7, h: 0.5,
      fontFace: FONT_HEAD, fontSize: 22, bold: true, color: GOLD, isTextBox: true, margin: 0,
    });
    s.addText(m.head, {
      x: x + 0.25, y: y + 0.72, w: 3.4, h: 0.4,
      fontFace: FONT_HEAD, fontSize: 14.5, bold: true, color: NAVY_DARK, isTextBox: true, margin: 0,
    });
    s.addText(m.body, {
      x: x + 0.25, y: y + 1.12, w: 3.4, h: 1.05,
      fontFace: FONT_BODY, fontSize: 11, color: INK_SOFT, isTextBox: true, margin: 0, lineSpacingMultiple: 1.15,
    });
  });
  pageNumber(s, 7);
}

// =====================================================================
// SLIDE 8 — SAMPLE OUTPUT (mock result card)
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "Demo");
  title(s, "Sample output");

  // Left: mock input summary
  s.addShape(pres.ShapeType.roundRect, {
    x: 0.6, y: 2.0, w: 4.6, h: 4.6, rectRadius: 0.1,
    fill: { color: WHITE }, line: { color: LINE, width: 1 },
  });
  s.addText("Input", {
    x: 0.9, y: 2.25, w: 4, h: 0.35, fontFace: FONT_HEAD, fontSize: 15, bold: true, color: NAVY_DARK,
    isTextBox: true, margin: 0,
  });
  const inputLines = [
    ["Student", "Asha Verma  (21CS045)"],
    ["Mathematics", "88 / 100"],
    ["Science", "76 / 100"],
    ["English", "91 / 100"],
  ];
  inputLines.forEach((row, i) => {
    const y = 2.75 + i * 0.55;
    s.addText(row[0], { x: 0.9, y, w: 2.0, h: 0.4, fontFace: FONT_BODY, fontSize: 12.5, color: INK_SOFT, isTextBox: true, margin: 0, valign: "middle" });
    s.addText(row[1], { x: 2.9, y, w: 2.2, h: 0.4, fontFace: FONT_BODY, fontSize: 12.5, bold: true, color: INK, isTextBox: true, margin: 0, valign: "middle" });
    if (i < inputLines.length - 1) {
      s.addShape(pres.ShapeType.line, { x: 0.9, y: y + 0.5, w: 3.9, h: 0, line: { color: LINE, width: 0.75 } });
    }
  });

  // Right: mock result card (mirrors the actual UI)
  s.addShape(pres.ShapeType.roundRect, {
    x: 5.5, y: 2.0, w: 7.2, h: 4.6, rectRadius: 0.1,
    fill: { color: NAVY }, line: { type: "none" },
  });
  s.addText("Result", { x: 5.85, y: 2.25, w: 3, h: 0.35, fontFace: FONT_HEAD, fontSize: 15, bold: true, color: GOLD, isTextBox: true, margin: 0 });

  s.addShape(pres.ShapeType.roundRect, {
    x: 10.6, y: 2.2, w: 1.7, h: 0.5, rectRadius: 0.25, fill: { color: PASS_BG }, line: { type: "none" },
  });
  s.addText("PASS", { x: 10.6, y: 2.2, w: 1.7, h: 0.5, align: "center", valign: "middle", fontFace: FONT_BODY, fontSize: 13, bold: true, color: PASS_GREEN, isTextBox: true, margin: 0 });

  const stats = [
    { label: "Percentage", value: "85%" },
    { label: "Grade", value: "A" },
    { label: "GPA / 10", value: "9.0" },
  ];
  stats.forEach((st, i) => {
    const x = 5.85 + i * 2.15;
    s.addText(st.value, { x, y: 2.95, w: 1.9, h: 0.65, align: "center", fontFace: FONT_HEAD, fontSize: 28, bold: true, color: WHITE, isTextBox: true, margin: 0 });
    s.addText(st.label, { x, y: 3.55, w: 1.9, h: 0.35, align: "center", fontFace: FONT_BODY, fontSize: 10.5, color: ICE, isTextBox: true, margin: 0 });
  });

  const subjRows = [
    ["Mathematics", "88/100", "88%", "A"],
    ["Science", "76/100", "76%", "B"],
    ["English", "91/100", "91%", "A+"],
  ];
  subjRows.forEach((row, i) => {
    const y = 4.35 + i * 0.62;
    ["Subject", "Marks", "%", "Grade"].forEach((h, ci) => {
      if (i === 0) {
        s.addText(h, {
          x: 5.85 + ci * 1.55, y: 4.05, w: 1.5, h: 0.3, fontFace: FONT_BODY, fontSize: 10.5, color: ICE, isTextBox: true, margin: 0,
        });
      }
    });
    row.forEach((cell, ci) => {
      s.addText(cell, {
        x: 5.85 + ci * 1.55, y, w: 1.5, h: 0.5, valign: "middle",
        fontFace: FONT_BODY, fontSize: 12, color: WHITE, isTextBox: true, margin: 0,
      });
    });
  });
  pageNumber(s, 8);
}

// =====================================================================
// SLIDE 9 — ADVANTAGES & FUTURE SCOPE
// =====================================================================
{
  const s = lightSlide();
  kicker(s, "Evaluation");
  title(s, "Advantages & future scope");

  s.addShape(pres.ShapeType.roundRect, {
    x: 0.6, y: 2.0, w: 5.9, h: 4.6, rectRadius: 0.1, fill: { color: WHITE }, line: { color: LINE, width: 1 },
  });
  s.addText("Advantages", { x: 0.9, y: 2.25, w: 5, h: 0.4, fontFace: FONT_HEAD, fontSize: 17, bold: true, color: PASS_GREEN, isTextBox: true, margin: 0 });
  [
    "Removes manual calculation errors entirely",
    "Consistent grading scale applied every time",
    "Instant results — no waiting for manual checking",
    "Clear separation of frontend, API and logic layers",
    "No database setup needed to get started",
  ].forEach((t, i) => {
    s.addText(t, {
      x: 0.9, y: 2.8 + i * 0.65, w: 5.3, h: 0.6, valign: "middle",
      fontFace: FONT_BODY, fontSize: 13, color: INK, bullet: { code: "2713", indent: 18 },
      isTextBox: true, margin: 0,
    });
  });

  s.addShape(pres.ShapeType.roundRect, {
    x: 6.8, y: 2.0, w: 5.9, h: 4.6, rectRadius: 0.1, fill: { color: WHITE }, line: { color: LINE, width: 1 },
  });
  s.addText("Future scope", { x: 7.1, y: 2.25, w: 5, h: 0.4, fontFace: FONT_HEAD, fontSize: 17, bold: true, color: NAVY, isTextBox: true, margin: 0 });
  [
    "Move history storage to MongoDB or PostgreSQL",
    "Add login for students and teachers",
    "Export a result as a downloadable PDF report card",
    "Support credit-weighted GPA for university courses",
    "Deploy live (Render/Railway + Vercel/Netlify)",
  ].forEach((t, i) => {
    s.addText(t, {
      x: 7.1, y: 2.8 + i * 0.65, w: 5.3, h: 0.6, valign: "middle",
      fontFace: FONT_BODY, fontSize: 13, color: INK, bullet: { code: "2192", indent: 18 },
      isTextBox: true, margin: 0,
    });
  });
  pageNumber(s, 9);
}

// =====================================================================
// SLIDE 10 — CONCLUSION / THANK YOU
// =====================================================================
{
  const s = darkSlide();
  s.addShape(pres.ShapeType.ellipse, {
    x: -2.5, y: 4.2, w: 6.5, h: 6.5, fill: { color: NAVY, transparency: 40 }, line: { type: "none" },
  });
  s.addText("CONCLUSION", {
    x: 0.8, y: 2.2, w: 6, h: 0.4, fontFace: FONT_BODY, fontSize: 13, bold: true, color: GOLD, charSpacing: 2,
    isTextBox: true, margin: 0,
  });
  s.addText("A small project,\nbuilt the right way.", {
    x: 0.75, y: 2.65, w: 9, h: 1.8, fontFace: FONT_HEAD, fontSize: 38, bold: true, color: WHITE,
    isTextBox: true, margin: 0, lineSpacingMultiple: 1.05,
  });
  s.addText("This project shows that a focused mini-project — a clean API, a small set of pure functions for the business logic, and a simple UI — can be both easy to build and genuinely useful. The same structure scales to a real gradebook system with a database and authentication layered on top.", {
    x: 0.8, y: 4.4, w: 8.2, h: 1.2, fontFace: FONT_BODY, fontSize: 14, color: ICE,
    isTextBox: true, margin: 0, lineSpacingMultiple: 1.25,
  });
  s.addShape(pres.ShapeType.line, { x: 0.8, y: 6.0, w: 3.2, h: 0, line: { color: GOLD, width: 1.5 } });
  s.addText("Thank you — questions welcome", {
    x: 0.8, y: 6.15, w: 8, h: 0.5, fontFace: FONT_HEAD, fontSize: 18, bold: true, color: WHITE,
    isTextBox: true, margin: 0,
  });
}

// ---------- Save ----------
pres.writeFile({ fileName: "Student_Grade_Calculator.pptx" }).then(() => {
  console.log("Deck written.");
});
